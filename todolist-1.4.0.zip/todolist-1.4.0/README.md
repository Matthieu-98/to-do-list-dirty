# How to commit ?

<type>[scope optionnel]: <description>

feat(tasks): ajout du tri des tâches
fix(tasks): correction du bug d'affichage
docs: mise à jour du README

# How to update versions ? 

MAJOR.MINOR.PATCH

MAJOR : changements incompatibles ou refonte majeure

MINOR : nouvelles fonctionnalités compatibles

PATCH : corrections de bugs ou améliorations mineures

1.0.0 : version initiale
1.1.0 : ajout d’une fonctionnalité
1.1.1 : correction de bugs
2.0.0 : refonte majeure

# How to genarate tarball ?

./build.sh version=X.Y.Z

